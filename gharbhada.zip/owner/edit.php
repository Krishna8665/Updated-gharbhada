<?php
session_start();
$property_id = '';
include("../config/config.php");

if (isset($_POST['property_id'])) {
  edit_property();
}


function edit_property()
{
  global $db, $property_id;

  $property_id = $_POST['property_id'];

  $country = validate($_POST['country']);
  $province = validate($_POST['province']);
  $zone = validate($_POST['zone']);
  $district = validate($_POST['district']);
  $city = validate($_POST['city']);
  $vdc_municipality = validate($_POST['vdc_municipality']);
  $ward_no = validate($_POST['ward_no']);
  $tole = validate($_POST['tole']);
  $contact_no = validate($_POST['contact_no']);
  $property_type = validate($_POST['property_type']);
  $estimated_price = validate($_POST['estimated_price']);
  $total_rooms = validate($_POST['total_rooms']);
  $bedroom = validate($_POST['bedroom']);
  $living_room = validate($_POST['living_room']);
  $kitchen = validate($_POST['kitchen']);
  $bathroom = validate($_POST['bathroom']);
  $description = validate($_POST['description']);
  $booked = validate($_POST['booked']);


    $sql3 = "UPDATE `add_property` SET `country`='$country',`province`='$province',`zone`='$zone',
`district`='$district',`city`='$city',`vdc_municipality`='$vdc_municipality',`ward_no`='$ward_no',`tole`='$tole',
`contact_no`='$contact_no',`property_type`='$property_type',`estimated_price`='$estimated_price',`total_rooms`='$total_rooms',
`bedroom`='$bedroom',`living_room`='$living_room',`kitchen`='$kitchen',`bathroom`='$bathroom',`description`='$description'
,`booked`='$booked' WHERE  property_id = $property_id";
    $query3 = mysqli_query($db, $sql3);
    if ($query3) {
      $_SESSION['msg'] = "Property edited Successfully";
      header("Location:index.php");

    }else{
      $_SESSION['msg'] = "Failed to edit";
      header("Location:index.php");
    }
}

function validate($data)
{
  $data = trim($data);
  $data = stripcslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


?>
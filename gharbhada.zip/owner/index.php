<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ownerindex</title>
</head>

<body>
    <?php
    include 'navbar.php';

    include("owner-backend.php");
    ?>


    <div class="main-content">
        <div class="row">
            <div class="col-md-12">
                <div class="table-wrapper">

                    <div class="table-title">
                        <div class="row">
                            <div class="col-sm-6 p-0 flex justify-content-lg-start justify-content-center">
                                <h2 class="ml-lg-2">View Properties</h2>
                            </div>
                            <div class="col-sm-6 p-0 flex justify-content-lg-end justify-content-center">
                                <a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal">
                                    <i class="material-icons">&#xE147;</i>
                                    <span>Add New Property</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <table id="myTable" class="table table-striped table-hover">
                        <thead>
                            <th>Id.</th>
                            <th>Country</th>
                            <th>Province/State</th>
                            <th>Zone</th>
                            <th>District</th>
                            <th>City</th>
                            <th>VDC/Municipality</th>
                            <th>Ward No.</th>
                            <th>House no</th>
                            <th>Contact No.</th>
                            <th>Property Type</th>
                            <th>Estmated Price</th>
                            <th>Total Rooms</th>
                            <th>Bedroom</th>
                            <th>Living Room</th>
                            <th>Kitchen</th>
                            <th>Bathroom</th>
                            <th>Description</th>
                            <th>Photos</th>
                            <th>Edit/Delete</th>
                        </thead>

                        <tbody>
                            <?php
                            $u_email = $_SESSION['email'];
                            $sql1 = "SELECT * from owner where email='$u_email'";
                            $result1 = mysqli_query($db, $sql1);

                            if (mysqli_num_rows($result1) > 0) {
                                while ($rowss = mysqli_fetch_assoc($result1)) {
                                    $owner_id = $rowss['owner_id'];

                                    $sql = "SELECT * from add_property where owner_id='$owner_id'";
                                    $result = mysqli_query($db, $sql);

                                    if (mysqli_num_rows($result) > 0) {
                                        while ($rows = mysqli_fetch_assoc($result)) {
                                            $property_id = $rows['property_id'];
                            ?>
                                            <tr>
                                                <td><?php echo $rows['property_id'] ?></td>
                                                <td><?php echo $rows['country'] ?></td>
                                                <td><?php echo $rows['province'] ?></td>
                                                <td><?php echo $rows['zone'] ?></td>
                                                <td><?php echo $rows['district'] ?></td>
                                                <td><?php echo $rows['city'] ?></td>
                                                <td><?php echo $rows['vdc_municipality'] ?></td>
                                                <td><?php echo $rows['ward_no'] ?></td>
                                                <td><?php echo $rows['tole'] ?></td>
                                                <td><?php echo $rows['contact_no'] ?></td>
                                                <td><?php echo $rows['property_type'] ?></td>
                                                <td>Rs.<?php echo $rows['estimated_price'] ?></td>
                                                <td><?php echo $rows['total_rooms'] ?></td>
                                                <td><?php echo $rows['bedroom'] ?></td>
                                                <td><?php echo $rows['living_room'] ?></td>
                                                <td><?php echo $rows['kitchen'] ?></td>
                                                <td><?php echo $rows['bathroom'] ?></td>
                                                <td><?php echo $rows['description'] ?></td>
                                                <td>
                                                    <?php $sql2 = "SELECT * from property_photo where property_id='$property_id'";
                                                    $query = mysqli_query($db, $sql2);

                                                    if (mysqli_num_rows($query) > 0) {
                                                        while ($row = mysqli_fetch_assoc($query)) { ?>
                                                            <img src="<?php echo $row['p_photo'] ?>" style="height:50px;width=50px;">
                                                    <?php }
                                                    }
                                                    ?>
                                                </td>
                                                <form method="POST">
                                                    <td>
                                                        <a href="#editEmployeeModal" class="btn btn-success" data-toggle="modal">Edit</a>
                                                        <a href="delete.php?property_id=<?php echo $property_id; ?>"><button class="btn btn-sm btn-danger" type="button">Delete</button></a>
                                                    </td>
                                                </form>
                                                <div class="modal fade" tabindex="-1" id="editEmployeeModal" role="dialog">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title">Edit Property</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="POST" action="edit.php" enctype="multipart/form-data">
                                                                    <input type="text" value="<?php echo $rows['property_id'] ?>" name="property_id">
                                                                    <div class="row">
                                                                        <div class="col-sm-6">
                                                                            <div class="form-group">
                                                                                <label for="country">Country:</label>
                                                                                <select class="form-control" name="country" required="required">
                                                                                    <option value="">--Select Country--</option>
                                                                                    <option value="Nepal" <?php if($rows['country'] == "Nepal"){  echo ' selected="selected"'; } ?>>Nepal</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="province">Province/State:</label>
                                                                                <select class="form-control" name="province" required="required">
                                                                                    <option value="">--Select Province/State--</option>
                                                                                    <option value="Province No. 1" <?php if($rows['province'] == "Province No. 1"){  echo ' selected="selected"'; } ?>>Province No. 1</option>
                                                                                    <option value="Province No. 2" <?php if($rows['province'] == "Province No. 2"){  echo ' selected="selected"'; } ?>>Province No. 2</option>
                                                                                    <option value="Bagmati Pradesh" <?php if($rows['province'] == "Bagmati Pradesh"){  echo ' selected="selected"'; } ?>>Bagmati Pradesh</option>
                                                                                    <option value="Gandaki Pradesh" <?php if($rows['province'] == "Gandaki Pradesh"){  echo ' selected="selected"'; } ?>>Gandaki Pradesh</option>
                                                                                    <option value="Province No. 5" <?php if($rows['province'] == "Province No. 5"){  echo ' selected="selected"'; } ?>>Province No. 5</option>
                                                                                    <option value="Karnali Pradesh" <?php if($rows['province'] == "Karnali Pradesh"){  echo ' selected="selected"'; } ?>>Karnali Pradesh</option>
                                                                                    <option value="Sudurpaschim Pradesh" <?php if($rows['province'] == "Sudurpaschim Pradesh"){  echo ' selected="selected"'; } ?>>Sudurpaschim Pradesh</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="zone">Zone:</label>
                                                                                <select class="form-control" name="zone" required="required">
                                                                                    <option value="">--Select Zone--</option>
                                                                                    <option value="Bagmati" <?php if($rows['zone'] == "Bagmati"){  echo ' selected="selected"'; } ?>>Bagmati</option>
                                                                                    <option value="Bheri" <?php if($rows['zone'] == "Bheri"){  echo ' selected="selected"'; } ?>>Bheri</option>
                                                                                    <option value="Dhawalagiri" <?php if($rows['zone'] == "Dhawalagiri"){  echo ' selected="selected"'; } ?>>Dhawalagiri</option>
                                                                                    <option value="Gandaki" <?php if($rows['zone'] == "Gandaki"){  echo ' selected="selected"'; } ?>>Gandaki</option>
                                                                                    <option value="Janakpur" <?php if($rows['zone'] == "Janakpur"){  echo ' selected="selected"'; } ?>>Janakpur</option>
                                                                                    <option value="Karnali" <?php if($rows['zone'] == "Karnali"){  echo ' selected="selected"'; } ?>>Karnali</option>
                                                                                    <option value="Kosi" <?php if($rows['zone'] == "Kosi"){  echo ' selected="selected"'; } ?>>Kosi</option>
                                                                                    <option value="Lumbini" <?php if($rows['zone'] == "Lumbini"){  echo ' selected="selected"'; } ?>>Lumbini</option>
                                                                                    <option value="Mahakali" <?php if($rows['zone'] == "Mahakali"){  echo ' selected="selected"'; } ?>>Mahakali</option>
                                                                                    <option value="Mechi" <?php if($rows['zone'] == "Mechi"){  echo ' selected="selected"'; } ?>>Mechi</option>
                                                                                    <option value="Narayani" <?php if($rows['zone'] == "Narayani"){  echo ' selected="selected"'; } ?>>Narayani</option>
                                                                                    <option value="Rapti" <?php if($rows['zone'] == "Rapti"){  echo ' selected="selected"'; } ?>>Rapti</option>
                                                                                    <option value="Sagarmatha" <?php if($rows['zone'] == "Sagarmatha"){  echo ' selected="selected"'; } ?>>Sagarmatha</option>
                                                                                    <option value="Seti" <?php if($rows['zone'] == "Seti"){  echo ' selected="selected"'; } ?>>Seti</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="district">District:</label>
                                                                                <select class="form-control" name="district" required="required">
                                                                                    %{--Mechi--}%
                                                                                    <option value="">--Select District--</option>
                                                                                    <option value="Taplejung" <?php if($rows['district'] == "Taplejung"){  echo ' selected="selected"'; } ?>>Taplejung</option>
                                                                                    <option value="Panchthar" <?php if($rows['district'] == "Panchthar"){  echo ' selected="selected"'; } ?>>Panchthar</option>
                                                                                    <option value="Ilam" <?php if($rows['district'] == "Ilam"){  echo ' selected="selected"'; } ?>>Ilam</option>
                                                                                    <option value="Jhapa" <?php if($rows['district'] == "Jhapa"){  echo ' selected="selected"'; } ?>>Jhapa</option>
                                                                                    %{--Koshi--}%
                                                                                    <option value="Morang" <?php if($rows['district'] == "Morang"){  echo ' selected="selected"'; } ?>>Morang</option>
                                                                                    <option value="Sunsari" <?php if($rows['district'] == "Sunsari"){  echo ' selected="selected"'; } ?>>Sunsari</option>
                                                                                    <option value="Dhankuta" <?php if($rows['district'] == "Dhankuta"){  echo ' selected="selected"'; } ?>>Dhankutta</option>
                                                                                    <option value="Sankhuwasabha" <?php if($rows['district'] == "Sankhuwasabha"){  echo ' selected="selected"'; } ?>>Sankhuwasabha</option>
                                                                                    <option value="Bhojpur" <?php if($rows['district'] == "Bhojpur"){  echo ' selected="selected"'; } ?>>Bhojpur</option>
                                                                                    <option value="Terhathum" <?php if($rows['district'] == "Terhathum"){  echo ' selected="selected"'; } ?>>Terhathum</option>
                                                                                    %{--Sagarmatha--}%
                                                                                    <option value="Okhaldunga" <?php if($rows['district'] == "Okhaldunga"){  echo ' selected="selected"'; } ?> >Okhaldunga</option>
                                                                                    <option value="Khotang" <?php if($rows['district'] == "Khotang"){  echo ' selected="selected"'; } ?>>Khotang</option>
                                                                                    <option value="Solukhumbu" <?php if($rows['district'] == "Solukhumbu"){  echo ' selected="selected"'; } ?>>Solukhumbu</option>
                                                                                    <option value="Udaypur" <?php if($rows['district'] == "Udaypur"){  echo ' selected="selected"'; } ?>>Udaypur</option>
                                                                                    <option value="Saptari" <?php if($rows['district'] == "Saptari"){  echo ' selected="selected"'; } ?>>Saptari</option>
                                                                                    <option value="Siraha" <?php if($rows['district'] == "Siraha"){  echo ' selected="selected"'; } ?>>Siraha</option>
                                                                                    %{--Janakpur--}%
                                                                                    <option value="Dhanusa" <?php if($rows['district'] == "Dhanusa"){  echo ' selected="selected"'; } ?>>Dhanusa</option>
                                                                                    <option value="Mahottari" <?php if($rows['district'] == "Mahottari"){  echo ' selected="selected"'; } ?>>Mahottari</option>
                                                                                    <option value="Sarlahi" <?php if($rows['district'] == "Sarlahi"){  echo ' selected="selected"'; } ?>>Sarlahi</option>
                                                                                    <option value="Sindhuli" <?php if($rows['district'] == "Sindhuli"){  echo ' selected="selected"'; } ?>>Sindhuli</option>
                                                                                    <option value="Ramechhap" <?php if($rows['district'] == "Ramechhap"){  echo ' selected="selected"'; } ?>>Ramechhap</option>
                                                                                    <option value="Dolkha" <?php if($rows['district'] == "Dolkha"){  echo ' selected="selected"'; } ?>>Dolkha</option>
                                                                                    %{--Bagmati--}%
                                                                                    <option value="Sindhupalchowk" <?php if($rows['district'] == "Sindhupalchowk"){  echo ' selected="selected"'; } ?>>Sindhupalchauk</option>
                                                                                    <option value="Kavreplanchowk" <?php if($rows['district'] == "Kavreplanchowk"){  echo ' selected="selected"'; } ?>>Kavreplanchauk</option>
                                                                                    <option value="Lalitpur" <?php if($rows['district'] == "Lalitpur"){  echo ' selected="selected"'; } ?>>Lalitpur</option>
                                                                                    <option value="Bhaktapur" <?php if($rows['district'] == "Bhaktapur"){  echo ' selected="selected"'; } ?>>Bhaktapur</option>
                                                                                    <option value="Kathmandu" <?php if($rows['district'] == "Kathmandu"){  echo ' selected="selected"'; } ?>>Kathmandu</option>
                                                                                    <option value="Nuwakot" <?php if($rows['district'] == "Nuwakot"){  echo ' selected="selected"'; } ?>>Nuwakot</option>
                                                                                    <option value="Rasuwa" <?php if($rows['district'] == "Rasuwa"){  echo ' selected="selected"'; } ?>>Rasuwa</option>
                                                                                    <option value="Dhading" <?php if($rows['district'] == "Dhading"){  echo ' selected="selected"'; } ?>>Dhading</option>
                                                                                    %{--Narayani--}%
                                                                                    <option value="Makwanpur" <?php if($rows['district'] == "Makwanpur"){  echo ' selected="selected"'; } ?>>Makwanpur</option>
                                                                                    <option value="Rauthat"<?php if($rows['district'] == "Rauthat"){  echo ' selected="selected"'; } ?>>Rauthat</option>
                                                                                    <option value="Bara"<?php if($rows['district'] == "Bara"){  echo ' selected="selected"'; } ?>>Bara</option>
                                                                                    <option value="Parsa" <?php if($rows['district'] == "Parsa"){  echo ' selected="selected"'; } ?>>Parsa</option>
                                                                                    <option value="Chitwan" <?php if($rows['district'] == "Chitwan"){  echo ' selected="selected"'; } ?>>Chitwan</option>
                                                                                    %{--Gandaki--}%
                                                                                    <option value="Gorkha" <?php if($rows['district'] == "Gorkha"){  echo ' selected="selected"'; } ?>>Gorkha</option>
                                                                                    <option value="Lamjung" <?php if($rows['district'] == "Lamjung"){  echo ' selected="selected"'; } ?>>Lamjung</option>
                                                                                    <option value="Tanahun" <?php if($rows['district'] == "Tanahun"){  echo ' selected="selected"'; } ?>>Tanahun</option>
                                                                                    <option value="Syangja" <?php if($rows['district'] == "Syangja"){  echo ' selected="selected"'; } ?>>Syangja</option>
                                                                                    <option value="Kaski" <?php if($rows['district'] == "Kaski"){  echo ' selected="selected"'; } ?>>Kaski</option>
                                                                                    <option value="Manang" <?php if($rows['district'] == "Manang"){  echo ' selected="selected"'; } ?>>Manag</option>
                                                                                    %{--Dhawalagiri--}%
                                                                                    <option value="Mustang"<?php if($rows['district'] == "Mustang"){  echo ' selected="selected"'; } ?>>Mustang</option>
                                                                                    <option value="Parbat" <?php if($rows['district'] == "Parbat"){  echo ' selected="selected"'; } ?>>Parwat</option> 
                                                                                    <option value="Myagdi" <?php if($rows['district'] == "Myagdi"){  echo ' selected="selected"'; } ?>>Myagdi</option>
                                                                                    <option value="Baglung" <?php if($rows['district'] == "Baglung"){  echo ' selected="selected"'; } ?>>Baglung</option>
                                                                                    %{--Lumbini--}%
                                                                                    <option value="Gulmi"<?php if($rows['district'] == "Gulmi"){  echo ' selected="selected"'; } ?>>Gulmi</option>
                                                                                    <option value="Palpa"<?php if($rows['district'] == "Palpa"){  echo ' selected="selected"'; } ?>>Palpa</option>
                                                                                    <option value="Nawalparasi"<?php if($rows['district'] == "Nawalparasi"){  echo ' selected="selected"'; } ?>>Nawalparasi</option>
                                                                                    <option value="Rupandehi"<?php if($rows['district'] == "Rupandehi"){  echo ' selected="selected"'; } ?>>Rupandehi</option>
                                                                                    <option value="Arghakhanchi"<?php if($rows['district'] == "Arghakhanchi"){  echo ' selected="selected"'; } ?>>Arghakhanchi</option>
                                                                                    <option value="Kapilvastu"<?php if($rows['district'] == "Kapilvastu"){  echo ' selected="selected"'; } ?>>Kapilvastu</option>
                                                                                    %{--Rapti--}%
                                                                                    <option value="Pyuthan"<?php if($rows['district'] == "Pyuthan"){  echo ' selected="selected"'; } ?>>Pyuthan</option>
                                                                                    <option value="Rolpa"<?php if($rows['district'] == "Rolpa"){  echo ' selected="selected"'; } ?>>Rolpa</option>
                                                                                    <option value="Rukum"<?php if($rows['district'] == "Rukum"){  echo ' selected="selected"'; } ?>>Rukum</option>
                                                                                    <option value="Salyan"<?php if($rows['district'] == "Salyan"){  echo ' selected="selected"'; } ?>>Salyan</option>
                                                                                    <option value="Dang"<?php if($rows['district'] == "Dang"){  echo ' selected="selected"'; } ?>>Dang</option>
                                                                                    %{--Bheri--}%
                                                                                    <option value="Bardiya" <?php if($rows['district'] == "Bardiya"){  echo ' selected="selected"'; } ?>>Bardiya</option>
                                                                                    <option value="Surkhet"<?php if($rows['district'] == "Surkhet"){  echo ' selected="selected"'; } ?>>Surkhet</option>
                                                                                    <option value="Dailekh"<?php if($rows['district'] == "Dailekh"){  echo ' selected="selected"'; } ?>>Dailekh</option>
                                                                                    <option value="Banke"<?php if($rows['district'] == "Banke"){  echo ' selected="selected"'; } ?>>Banke</option>
                                                                                    <option value="Jajarkot"<?php if($rows['district'] == "Jajarkot"){  echo ' selected="selected"'; } ?>>Jajarkot</option>
                                                                                    %{--Karnali--}%
                                                                                    <option value="Dolpa"<?php if($rows['district'] == "Dolpa"){  echo ' selected="selected"'; } ?>>Dolpa</option>
                                                                                    <option value="Humla"<?php if($rows['district'] == "Humla"){  echo ' selected="selected"'; } ?>>Humla</option>
                                                                                    <option value="Kalikot"<?php if($rows['district'] == "Kalikot"){  echo ' selected="selected"'; } ?>>Kalikot</option>
                                                                                    <option value="Mugu"<?php if($rows['district'] == "Mugu"){  echo ' selected="selected"'; } ?>>Mugu</option>
                                                                                    <option value="Jumla"<?php if($rows['district'] == "Jumla"){  echo ' selected="selected"'; } ?>s>Jumla</option>
                                                                                    %{--Seti--}%
                                                                                    <option value="Bajura"<?php if($rows['district'] == "Bajura"){  echo ' selected="selected"'; } ?>>Bajura</option>
                                                                                    <option value="Bajhang"<?php if($rows['district'] == "Bajhang"){  echo ' selected="selected"'; } ?>>Bajhang</option>
                                                                                    <option value="Achham"<?php if($rows['district'] == "Achham"){  echo ' selected="selected"'; } ?>>Achham</option>
                                                                                    <option value="Doti"<?php if($rows['district'] == "Doti"){  echo ' selected="selected"'; } ?>>Doti</option>
                                                                                    <option value="Kailali"<?php if($rows['district'] == "Kailali"){  echo ' selected="selected"'; } ?>>Kailali</option>
                                                                                    %{--Mahakali--}%
                                                                                    <option value="Kanchanpur"<?php if($rows['district'] == "Kanchanpur"){  echo ' selected="selected"'; } ?>>Kanchanpur</option>
                                                                                    <option value="Dadeldhura"<?php if($rows['district'] == "Dadeldhura"){  echo ' selected="selected"'; } ?>>Dadeldhura</option>
                                                                                    <option value="Baitadi"<?php if($rows['district'] == "Baitadi"){  echo ' selected="selected"'; } ?>>Baitadi</option>
                                                                                    <option value="Darchula"<?php if($rows['district'] == "Darchula"){  echo ' selected="selected"'; } ?>>Darchula</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="city" >City:</label>
                                                                                <input type="text" class="form-control" id="city" placeholder="Enter City" value="<?php echo $rows['city'] ?>"  name="city">
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="vdc/municipality">VDC/Municipality:</label>
                                                                                <select class="form-control" name="vdc_municipality">
                                                                                    <option value="">--Select VDC/Municipality--</option>
                                                                                    <option value="VDC" <?php if($rows['vdc_municipality'] == "VDC"){  echo ' selected="selected"'; } ?>>VDC</option>
                                                                                    <option value="Municipality"<?php if($rows['vdc_municipality'] == "Municipality"){  echo ' selected="selected"'; } ?>>Municipality</option>
                                                                                </select>

                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="ward_no" >Ward No.:</label>
                                                                                <input type="text" class="form-control" id="ward_no" value="<?php echo $rows['ward_no'] ?>" placeholder="Enter Ward No." name="ward_no">
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="tole">Tole:</label>
                                                                                <input type="text" class="form-control" id="tole" placeholder="Enter Tole" value="<?php echo $rows['tole'] ?>" name="tole">
                                                                            </div>

                                                                        </div>

                                                                        <div class="col-sm-6">
                                                                            <div class="form-group">
                                                                                <label for="contact_no">Contact No.:</label>
                                                                                <input type="text" class="form-control" id="contact_no" placeholder="Enter Contact No." value="<?php echo $rows['contact_no'] ?>" name="contact_no">
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="property_type">Property Type:</label>
                                                                                <select class="form-control" name="property_type">
                                                                                    <option value="">--Select Property Type--</option>
                                                                                    <option value="Full House Rent" <?php if($rows['property_type'] == "Full House Rent"){  echo ' selected="selected"'; } ?>>Full House Rent</option>
                                                                                    <option value="Flat Rent" <?php if($rows['property_type'] == "Flat Rent"){  echo ' selected="selected"'; } ?>>Flat Rent</option>
                                                                                    <option value="Room Rent" <?php if($rows['property_type'] == "Room Rent"){  echo ' selected="selected"'; } ?>>Room Rent</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="estimated_price">Estimated Price:</label>
                                                                                <input type="estimated_price" class="form-control" id="estimated_price" placeholder="Enter Estimated Price" value="<?php echo $rows['estimated_price'] ?>" name="estimated_price">
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="total_rooms">Total No. of Rooms:</label>
                                                                                <input type="number" class="form-control" id="total_rooms" placeholder="Enter Total No. of Rooms" value="<?php echo $rows['total_rooms'] ?>" name="total_rooms">
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="bedroom">No. of Bedroom:</label>
                                                                                <input type="number" class="form-control" id="bedroom" placeholder="Enter No. of Bedroom" value="<?php echo $rows['bedroom'] ?>" name="bedroom">
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="living_room">No. of Living Room:</label>
                                                                                <input type="number" class="form-control" id="living_room" placeholder="Enter No. of Living Room" value="<?php echo $rows['living_room'] ?>"name="living_room">
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="kitchen">No. of Kitchen:</label>
                                                                                <input type="number" class="form-control" id="kitchen" placeholder="Enter No. of Kitchen" value="<?php echo $rows['kitchen'] ?>" name="kitchen">
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="bathroom">No. of Bathroom/Washroom:</label>
                                                                                <input type="number" class="form-control" id="bathroom" placeholder="Enter No. of Bathroom/Washroom" value="<?php echo $rows['bathroom'] ?>" name="bathroom">
                                                                            </div>

                                                                        </div>
                                                                        <div class="form-group">
                                                                                <label for="vdc/municipality">Booked:</label>
                                                                                <select class="form-control" name="booked">
                                                                                    <option value="">--Select Booked--</option>
                                                                                    <option value="Yes" <?php if($rows['booked'] == "Yes"){  echo ' selected="selected"'; } ?>>Yes</option>
                                                                                    <option value="No"<?php if($rows['booked'] == "No"){  echo ' selected="selected"'; } ?>>No</option>
                                                                                </select>

                                                                            </div>
                                                                        <div class="col-sm-12">
                                                                            <div class="form-group">
                                                                                <label for="description">Full Description:</label>
                                                                                <textarea type="comment" class="form-control" id="description" placeholder="Enter Property Description" name="description"><?php echo $rows['description'] ?></textarea>
                                                                            </div>
                                                                            <hr>
                                                                            <div class="form-group">
                                                                                <input type="submit" class="btn btn-primary btn-lg col-lg-12" value="Edit Property" name="add_property">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                <?php
                                        }
                                    }
                                }
                            } ?>
                                </td>

                                            </tr>
                        </tbody>


                    </table>









                </div>
            </div>


            <!----add-modal start--------->
            <div class="modal fade" tabindex="-1" id="addEmployeeModal" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Add Property</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form method="POST" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="country">Country:</label>
                                            <select class="form-control" name="country" required="required">
                                                <option value="">--Select Country--</option>
                                                <option value="Nepal">Nepal</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="province">Province/State:</label>
                                            <select class="form-control" name="province" required="required">
                                                <option value="">--Select Province/State--</option>
                                                <option value="Province No. 1">Province No. 1</option>
                                                <option value="Province No. 2">Province No. 2</option>
                                                <option value="Bagmati Pradesh">Bagmati Pradesh</option>
                                                <option value="Gandaki Pradesh">Gandaki Pradesh</option>
                                                <option value="Province No. 5">Province No. 5</option>
                                                <option value="Karnali Pradesh">Karnali Pradesh</option>
                                                <option value="Sudurpaschim Pradesh">Sudurpaschim Pradesh</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="zone">Zone:</label>
                                            <select class="form-control" name="zone" required="required">
                                                <option value="">--Select Zone--</option>
                                                <option value="Bagmati">Bagmati</option>
                                                <option value="Bheri">Bheri</option>
                                                <option value="Dhawalagiri">Dhawalagiri</option>
                                                <option value="Gandaki">Gandaki</option>
                                                <option value="Janakpur">Janakpur</option>
                                                <option value="Karnali">Karnali</option>
                                                <option value="Kosi">Kosi</option>
                                                <option value="Lumbini">Lumbini</option>
                                                <option value="Mahakali">Mahakali</option>
                                                <option value="Mechi">Mechi</option>
                                                <option value="Narayani">Narayani</option>
                                                <option value="Rapti">Rapti</option>
                                                <option value="Sagarmatha">Sagarmatha</option>
                                                <option value="Seti">Seti</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="district">District:</label>
                                            <select class="form-control" name="district" required="required">
                                                %{--Mechi--}%
                                                <option value="">--Select District--</option>
                                                <option value="Taplejung">Taplejung</option>
                                                <option value="Panchthar">Panchthar</option>
                                                <option value="Ilam">Ilam</option>
                                                <option value="Jhapa">Jhapa</option>
                                                %{--Koshi--}%
                                                <option value="Morang">Morang</option>
                                                <option value="Sunsari">Sunsari</option>
                                                <option value="Dhankutta">Dhankutta</option>
                                                <option value="Sankhuwasabha">Sankhuwasabha</option>
                                                <option value="Bhojpur">Bhojpur</option>
                                                <option value="Terhathum">Terhathum</option>
                                                %{--Sagarmatha--}%
                                                <option value="Okhaldunga">Okhaldunga</option>
                                                <option value="Khotang">Khotang</option>
                                                <option value="Solukhumbu">Solukhumbu</option>
                                                <option value="Udaypur">Udaypur</option>
                                                <option value="Saptari">Saptari</option>
                                                <option value="Siraha">Siraha</option>
                                                %{--Janakpur--}%
                                                <option value="Dhanusa">Dhanusa</option>
                                                <option value="Mahottari">Mahottari</option>
                                                <option value="Sarlahi">Sarlahi</option>
                                                <option value="Sindhuli">Sindhuli</option>
                                                <option value="Ramechhap">Ramechhap</option>
                                                <option value="Dolkha">Dolkha</option>
                                                %{--Bagmati--}%
                                                <option value="Sindhupalchauk">Sindhupalchauk</option>
                                                <option value="Kavreplanchauk">Kavreplanchauk</option>
                                                <option value="Lalitpur">Lalitpur</option>
                                                <option value="Bhaktapur">Bhaktapur</option>
                                                <option value="Kathmandu">Kathmandu</option>
                                                <option value="Nuwakot">Nuwakot</option>
                                                <option value="Rasuwa">Rasuwa</option>
                                                <option value="Dhading">Dhading</option>
                                                %{--Narayani--}%
                                                <option value="Makwanpur">Makwanpur</option>
                                                <option value="Rauthat">Rauthat</option>
                                                <option value="Bara">Bara</option>
                                                <option value="Parsa">Parsa</option>
                                                <option value="Chitwan">Chitwan</option>
                                                %{--Gandaki--}%
                                                <option value="Gorkha">Gorkha</option>
                                                <option value="Lamjung">Lamjung</option>
                                                <option value="Tanahun">Tanahun</option>
                                                <option value="Tanahun">Tanahun</option>
                                                <option value="Syangja">Syangja</option>
                                                <option value="Kaski">Kaski</option>
                                                <option value="Manag">Manag</option>
                                                %{--Dhawalagiri--}%
                                                <option value="Mustang">Mustang</option>
                                                <option value="Parwat">Parwat</option>
                                                <option value="Myagdi">Myagdi</option>
                                                <option value="Myagdi">Myagdi</option>
                                                <option value="Baglung">Baglung</option>
                                                %{--Lumbini--}%
                                                <option value="Gulmi">Gulmi</option>
                                                <option value="Palpa">Palpa</option>
                                                <option value="Nawalparasi">Nawalparasi</option>
                                                <option value="Rupandehi">Rupandehi</option>
                                                <option value="Arghakhanchi">Arghakhanchi</option>
                                                <option value="Kapilvastu">Kapilvastu</option>
                                                %{--Rapti--}%
                                                <option value="Pyuthan">Pyuthan</option>
                                                <option value="Rolpa">Rolpa</option>
                                                <option value="Rukum">Rukum</option>
                                                <option value="Salyan">Salyan</option>
                                                <option value="Dang">Dang</option>
                                                %{--Bheri--}%
                                                <option value="Bardiya">Bardiya</option>
                                                <option value="Surkhet">Surkhet</option>
                                                <option value="Dailekh">Dailekh</option>
                                                <option value="Banke">Banke</option>
                                                <option value="Jajarkot">Jajarkot</option>
                                                %{--Karnali--}%
                                                <option value="Dolpa">Dolpa</option>
                                                <option value="Humla">Humla</option>
                                                <option value="Kalikot">Kalikot</option>
                                                <option value="Mugu">Mugu</option>
                                                <option value="Jumla">Jumla</option>
                                                %{--Seti--}%
                                                <option value="Bajura">Bajura</option>
                                                <option value="Bajhang">Bajhang</option>
                                                <option value="Achham">Achham</option>
                                                <option value="Doti">Doti</option>
                                                <option value="Kailali">Kailali</option>
                                                %{--Mahakali--}%
                                                <option value="Kanchanpur">Kanchanpur</option>
                                                <option value="Dadeldhura">Dadeldhura</option>
                                                <option value="Baitadi">Baitadi</option>
                                                <option value="Darchula">Darchula</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="city">City:</label>
                                            <input type="text" class="form-control" id="city" placeholder="Enter City" name="city">
                                        </div>
                                        <div class="form-group">
                                            <label for="vdc/municipality">VDC/Municipality:</label>
                                            <select class="form-control" name="vdc_municipality">
                                                <option value="">--Select VDC/Municipality--</option>
                                                <option value="VDC">VDC</option>
                                                <option value="Municipality">Municipality</option>
                                            </select>

                                        </div>
                                        <div class="form-group">
                                            <label for="ward_no">Ward No.:</label>
                                            <input type="text" class="form-control" id="ward_no" placeholder="Enter Ward No." name="ward_no">
                                        </div>
                                        <div class="form-group">
                                            <label for="tole">House no:</label>
                                            <input type="text" class="form-control" id="tole" placeholder="Enter House no" name="tole">
                                        </div>

                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="contact_no">Contact No.:</label>
                                            <input type="text" class="form-control" id="contact_no" placeholder="Enter Contact No." name="contact_no">
                                        </div>
                                        <div class="form-group">
                                            <label for="property_type">Property Type:</label>
                                            <select class="form-control" name="property_type">
                                                <option value="">--Select Property Type--</option>
                                                <option value="Full House Rent">Full House Rent</option>
                                                <option value="Flat Rent">Flat Rent</option>
                                                <option value="Room Rent">Room Rent</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="estimated_price">Estimated Price:</label>
                                            <input type="estimated_price" class="form-control" id="estimated_price" placeholder="Enter Estimated Price" name="estimated_price">
                                        </div>
                                        <div class="form-group">
                                            <label for="total_rooms">Total No. of Rooms:</label>
                                            <input type="number" class="form-control" id="total_rooms" placeholder="Enter Total No. of Rooms" name="total_rooms">
                                        </div>
                                        <div class="form-group">
                                            <label for="bedroom">No. of Bedroom:</label>
                                            <input type="number" class="form-control" id="bedroom" placeholder="Enter No. of Bedroom" name="bedroom">
                                        </div>
                                        <div class="form-group">
                                            <label for="living_room">No. of Living Room:</label>
                                            <input type="number" class="form-control" id="living_room" placeholder="Enter No. of Living Room" name="living_room">
                                        </div>
                                        <div class="form-group">
                                            <label for="kitchen">No. of Kitchen:</label>
                                            <input type="number" class="form-control" id="kitchen" placeholder="Enter No. of Kitchen" name="kitchen">
                                        </div>
                                        <div class="form-group">
                                            <label for="bathroom">No. of Bathroom/Washroom:</label>
                                            <input type="number" class="form-control" id="bathroom" placeholder="Enter No. of Bathroom/Washroom" name="bathroom">
                                        </div>

                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="description">Full Description:</label>
                                            <textarea type="comment" class="form-control" id="description" placeholder="Enter Property Description" name="description"></textarea>
                                        </div>
                                        <table class="table" id="dynamic_field">
                                            <tr>
                                                <div class="form-group">
                                                    <label><b>Photos:</b></label>
                                                    <td><input type="file" name="p_photo[]" placeholder="Photos" class="form-control name_list" required accept="image/*" /></td>
                                                    <td><button type="button" id="add" name="add" class="btn btn-success btn-sm">+</button></td>
                                                </div>
                                            </tr>
                                        </table>
                                        <input name="lat" type="text" id="lat" hidden>
                                        <input name="lng" type="text" id="lng" hidden>
                                        <hr>
                                        <div class="form-group">
                                            <input type="submit" class="btn btn-primary btn-lg col-lg-12" value="Add Property" name="add_property">
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
    
    

    <script>
        $(document).ready(function() {
            var i = 1;
            $('#add').click(function() {
                i++;
                $('#dynamic_field').append('<tr id="row' + i +
                    '"><td><input type="file" name="p_photo[]" placeholder="Photos" class="form-control name_list" required accept="image/*" /></td></td> <td><button id="' +
                    i + '" class="btn btn-danger btn_remove">X</button></td></tr>');
            });
            $(document).on('click', '.btn_remove', function() {
                var button_id = $(this).attr("id");
                $('#row' + button_id + '').remove();
            });
            $('#submit').click(function() {

                $.ajax({
                    url: "name.php",
                    method: "POST",
                    data: $('#add_name').serialize(),
                    success: function(data) {
                        alert(data);
                        $('#add_name')[0].reset();
                    }
                });
            });
        });
    </script>
</body>

</html>
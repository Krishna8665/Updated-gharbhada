<?php 
session_start();
$property_id='';
include("../config/config.php");

if(isset($_GET['property_id'])){
	delete_property();
}


function delete_property(){
	global $db,$property_id;
		
$property_id=$_GET['property_id'];

$sql="DELETE from property_photo where property_id='$property_id'";
$query=mysqli_query($db,$sql);

if($query){
$sql3="DELETE from add_property where property_id='$property_id'";
$query3=mysqli_query($db,$sql3);
if($query3){
			
  $_SESSION['msg'] = "Property Deleted Successfully";
  header("Location:index.php");

}
}}


 ?>
<section id="about">
<table id="tab" >
	<tr>
		<th>
	        <h1 id="headings">
					<a href="about.html"><img src="img/logo.png" alt="ghar bhada logo" id="bottom" class="logo"></a><br>
				</h1>
				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
				<div class="wrapper">
				  <div class="button">
					 <div class="icon">
						<a href=""><i class="fab fa-facebook-f"></i></a>
					 </div>
				  </div>
				  <div class="button">
					 <div class="icon">
						<a href=""><i class="fab fa-twitter"></i></a>
					 </div>
				  </div>
				  <div class="button">
					 <div class="icon">
						<a href="www.instagram.com"><i class="fab fa-instagram"></i></a>
					 </div>
				  </div>
				  <div class="button">
					 <div class="icon">
						<a href="www.linkedin.com/in/rajiv-parajuli-39b449255"><i class="fab fa-linkedin"></i></a> 
					 </div>
				  </div>
			   </div>  
		</th>
		<th>
			<p class="describe">Based on pokhara valley, Ghar Bhada is a Room rental webapp</p>
			<p class="describe">that helps people find their desired accomodation.</p><br><br><br><br>
		</th>
		<th>
			<h2 class="main">Contact us</h1>
			<p class="small">Masbar, Pokhara, Nepal</p>
			<p class="small">9999999999</p> 
			<p><a class="linkss" href="mailto: be2019ce11@gces.np">be2019ce11@gces.np</a></p>
		</th>
	</tr>
</table>
<p class="describe">&copy 2022 GharBhada . All Rights Reserved</p>
</section>